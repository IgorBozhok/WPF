﻿using MangaShop.Helpers;
using MediaPlayer.Model.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MediaPlayer.Model.Repositories
{
	public class PlayListRepository : IRepository<MediaItem>
	{
		public IEnumerable<MediaItem> PlayList
		{
			get { return _playList; }
		}

		private ObservableCollection<MediaItem> _playList;

		public PlayListRepository()
		{
			try
			{
				_playList = SerializerHelper.Deserialize<MediaItem>("LastPlayList.plst");
			}
			catch
			{
				_playList = new ObservableCollection<MediaItem>();
			}
		}
		public void Add(MediaItem item)
		{
			if (item == null)
			{ throw new ArgumentNullException(); }
			_playList.Add(item);
		}

		public void Clear()
		{
			_playList.Clear();
		}

		public ObservableCollection<MediaItem> Load()
		{
			return _playList;
		}

		public void Open(string path)
		{
			try
			{
				_playList = SerializerHelper.Deserialize<MediaItem>(path);
			}
			catch
			{
				_playList = new ObservableCollection<MediaItem>();
				throw;
			}
		}

		public void Remove(MediaItem item)
		{
			if (item == null)
			{ throw new ArgumentNullException(); }
			_playList.Remove(item);
		}

		public void Save()
		{
			SerializerHelper.Serialize(_playList, "LastPlayList.plst");
		}

		public void SaveAs(string path)
		{
			SerializerHelper.Serialize(_playList, path);
		}
	}
}
