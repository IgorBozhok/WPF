﻿using System.Collections.ObjectModel;

namespace MediaPlayer.Model.Repositories
{
	public interface IRepository<T>
	{
		void Add(T item);
		void Remove(T item);
		void Save();
		void SaveAs(string path);
		void Open(string path);
		ObservableCollection<T> Load();
		void Clear();
	}
}
