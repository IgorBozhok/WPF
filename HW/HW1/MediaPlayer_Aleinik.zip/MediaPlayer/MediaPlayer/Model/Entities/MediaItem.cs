﻿using System;

namespace MediaPlayer.Model.Entities
{
	[Serializable]
	public class MediaItem
	{
		public string Name { get; private set; }
		public Uri Path { get; private set; }
		public MediaItem(string name, string uri)
		{
			Name = name;
			Path = new Uri(uri);
		}
		public override string ToString()
		{
			return Name;	
		}
	}
}
