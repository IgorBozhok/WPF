﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace MangaShop.Helpers
{
	public static class SerializerHelper
	{
		public static void Serialize<T>(IList<T> list, string fileName)
		{
			using (FileStream file = new FileStream(fileName, FileMode.OpenOrCreate))
			{
				BinaryFormatter serrializer = new BinaryFormatter();
				serrializer.Serialize(file, list);
			}
		}
		public static ObservableCollection<T> Deserialize<T>(string fileName)
		{
			using (FileStream file = new FileStream(fileName, FileMode.Open))
			{
				BinaryFormatter serrializer = new BinaryFormatter();
				return (ObservableCollection<T>)serrializer.Deserialize(file);
			}
		}
	}
}
