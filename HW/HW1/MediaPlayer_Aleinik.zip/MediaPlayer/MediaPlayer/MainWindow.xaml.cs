﻿using MediaPlayer.Model.Entities;
using MediaPlayer.Model.Repositories;
using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace MediaPlayer
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private DispatcherTimer timer;
		private PlayListRepository _playList;


		public MainWindow()
		{
			InitializeComponent();
			_playList = new PlayListRepository();
			timer = new DispatcherTimer();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			Layout.DataContext = _playList.PlayList;
			timer.Interval = TimeSpan.FromMilliseconds(300);
			timer.Tick += timer_Tick;
		}


		private void btnOpen_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog();
			if (dialog.ShowDialog() == true)
			{
				if (meMedia.Source != null)
				{
					Panel.SetZIndex(btnPause, 0);
					meMedia.Stop();
					timer.Stop();
					slTime.Value = 0;
				}
				meMedia.Source = new Uri(dialog.FileName);
			}
		}

		private void btnPlay_Click(object sender, RoutedEventArgs e)
		{
			if (meMedia.Source != null)
			{
				Play();
			}
			else
			{
				if (lstPlayList.SelectedItem != null)
				{
					var next = lstPlayList.SelectedItem as MediaItem;
					meMedia.Source = next.Path;
					Play();
				}
				else
				{
					if (lstPlayList.Items.Count != 0)
					{
						lstPlayList.SelectedIndex = 0;
						var next = lstPlayList.SelectedItem as MediaItem;
						meMedia.Source = next.Path;
						Play();
					}
				}
			}
		}

		private void Play()
		{
			Panel.SetZIndex(btnPause, 2);
			meMedia.Play();
			timer.Start();
		}

		private void btnPause_Click(object sender, RoutedEventArgs e)
		{
			if (meMedia.Source != null)
			{
				Panel.SetZIndex(btnPause, 0);
				meMedia.Pause();
				timer.Stop();
			}
		}

		private void btnStop_Click(object sender, RoutedEventArgs e)
		{
			if (meMedia.Source != null)
			{
				Panel.SetZIndex(btnPause, 0);
				meMedia.Stop();
				timer.Stop();
				slTime.Value = 0;
			}
		}

		private void btnPrevious_Click(object sender, RoutedEventArgs e)
		{
			if (lstPlayList.SelectedIndex != 0)
			{
				lstPlayList.SelectedIndex--;
			}
			else
			{
				lstPlayList.SelectedIndex = lstPlayList.Items.Count - 1;
			}
			var next = lstPlayList.SelectedItem as MediaItem;
			if (next != null)
				meMedia.Source = next.Path;
		}


		private void timer_Tick(object sender, EventArgs e)
		{
			slTime.Value = meMedia.Position.TotalMilliseconds;
		}

		private void meMedia_MediaOpened(object sender, RoutedEventArgs e)
		{			
			meMedia.Volume = (double)slVolume.Value;
			lblName.Content = Path.GetFileNameWithoutExtension(meMedia.Source.ToString());
			slTime.Maximum = meMedia.NaturalDuration.TimeSpan.TotalMilliseconds;
		}

		private void meMedia_MediaEnded(object sender, RoutedEventArgs e)
		{
			if (lstPlayList.SelectedIndex < lstPlayList.Items.Count - 1)
			{
				lstPlayList.SelectedIndex++;
			}
			else
			{
				lstPlayList.SelectedIndex = 0;
			}
			var next = lstPlayList.SelectedItem as MediaItem;
			if (next != null)
				meMedia.Source = next.Path;
		}

		private void btnAddToPlayList_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog();
			dialog.Multiselect = true;
			if (dialog.ShowDialog() == true)
			{
				for (int i = 0; i < dialog.FileNames.Length; i++)
				{
					_playList.Add(new MediaItem(dialog.SafeFileNames[i], dialog.FileNames[i]));
				}
				if(lstPlayList.SelectedItem==null)
				{
					lstPlayList.SelectedIndex = 0;
				}
			}
		}

		private void slTime_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (meMedia.NaturalDuration.HasTimeSpan)
			{
				lblTimePassed.Content = TimeSpan.FromMilliseconds(slTime.Value).ToString(@"hh\:mm\:ss");
				lblTimeLeft.Content = TimeSpan.FromMilliseconds(meMedia.NaturalDuration.TimeSpan.TotalMilliseconds - slTime.Value).ToString(@"hh\:mm\:ss");
			}
		}

		private void slVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (meMedia != null)
				meMedia.Volume = (double)slVolume.Value;
		}

		private void slTime_PreviewMouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			meMedia.Position = new TimeSpan(0, 0, 0, 0, (int)slTime.Value);
		}

		private void lstPlayList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			var next = lstPlayList.SelectedItem as MediaItem;
			if (next != null)
			{
				meMedia.Source = next.Path;
			}
		}

		private void btnRemove_Click(object sender, RoutedEventArgs e)
		{
			var element = lstPlayList.SelectedItem as MediaItem;
			if (element != null)
			{
				_playList.Remove(element);
			}
		}

		private void btnSavePlayList_Click(object sender, RoutedEventArgs e)
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "Playlist file | *.plst";
			if(saveFileDialog.ShowDialog()==true)
			{
				_playList.SaveAs(saveFileDialog.FileName);
			}
		}

		private void btnLoadPlayList_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "Playlist file | *.plst";
			if (openFileDialog.ShowDialog() == true)
			{
				try
				{
					_playList.Open(openFileDialog.FileName);
					Layout.DataContext = _playList.PlayList;
				}
				catch
				{
					MessageBox.Show("Ошибка открытия плейлиста", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
				}
			}
		}

		private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			_playList.Save();
		}
	}
}
